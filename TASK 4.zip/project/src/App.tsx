import React, { useState, useEffect } from 'react';
import { Brain, Zap, Settings, BookOpen, Sparkles, Play, RotateCcw } from 'lucide-react';

// Simulated text generation with different topics and creativity levels
const textSamples = {
  'artificial intelligence': {
    low: "Artificial intelligence represents a significant technological advancement in modern computing. Machine learning algorithms enable computers to process vast amounts of data and identify patterns that humans might miss. These systems are increasingly being deployed across various industries to automate tasks and improve efficiency. The development of AI continues to accelerate as researchers discover new methodologies and applications.",
    high: "Artificial intelligence dances at the crossroads of human dreams and silicon reality, weaving algorithmic tapestries that shimmer with possibility. Like digital neurons firing in concert, these computational minds explore realms beyond human imagination, crafting solutions that sparkle with innovation. The future unfolds through circuits and code, where artificial consciousness whispers secrets of tomorrow's technological renaissance."
  },
  'climate change': {
    low: "Climate change refers to long-term shifts in global temperatures and weather patterns. While climate variations occur naturally, scientific evidence shows that human activities have been the primary driver of climate change since the 1800s. The burning of fossil fuels generates greenhouse gas emissions that trap heat in the atmosphere, leading to rising global temperatures and various environmental impacts.",
    high: "Climate change orchestrates a planetary symphony of transformation, where melting glaciers compose haunting melodies and rising seas choreograph new coastlines. The Earth's atmosphere holds whispered conversations between carbon molecules and sunlight, scripting a narrative of consequence and hope. Each season writes its own chapter in this unfolding epic of environmental metamorphosis."
  },
  'space exploration': {
    low: "Space exploration involves the investigation of celestial bodies and phenomena beyond Earth's atmosphere. Space agencies and private companies develop sophisticated rockets and spacecraft to conduct missions to various destinations in our solar system. These endeavors contribute to scientific knowledge, technological advancement, and our understanding of the universe's fundamental properties.",
    high: "Space exploration beckons humanity toward cosmic ballet, where rockets pirouette through stellar stages and astronauts waltz among the stars. The universe unfolds like an infinite manuscript, its pages written in stardust and quantum mysteries. Each mission becomes a love letter to the cosmos, sealed with human courage and delivered to the infinite frontier of possibility."
  },
  'renewable energy': {
    low: "Renewable energy sources include solar, wind, hydroelectric, and geothermal power. These technologies harness natural processes to generate electricity without depleting finite resources. Solar panels convert sunlight into electrical energy, while wind turbines capture kinetic energy from moving air. The adoption of renewable energy systems helps reduce greenhouse gas emissions and dependence on fossil fuels.",
    high: "Renewable energy orchestrates nature's own power symphony, where solar panels dance with photons and wind turbines spin tales of atmospheric romance. The Earth offers its gifts freely – sunshine cascading like golden rivers, winds whispering secrets of kinetic possibility, and waters flowing with hydroelectric dreams. This green revolution paints the future in emerald hues of sustainable harmony."
  },
  'ocean conservation': {
    low: "Ocean conservation focuses on protecting marine ecosystems and biodiversity. The world's oceans face various threats including pollution, overfishing, and climate change. Conservation efforts involve establishing marine protected areas, reducing plastic waste, and implementing sustainable fishing practices. These initiatives aim to preserve ocean health for future generations and maintain the delicate balance of marine food chains.",
    high: "Ocean conservation whispers through coral cathedrals and kelp forests, where marine guardians protect liquid sanctuaries of blue wonder. The sea holds ancient wisdom in its depths, cradling creatures that shimmer like living jewels in underwater galaxies. Every wave carries stories of conservation heroes who weave protective spells around vulnerable ecosystems, ensuring that future generations inherit oceans that still sing with life."
  }
};

const examplePrompts = [
  'artificial intelligence',
  'climate change', 
  'space exploration',
  'renewable energy',
  'ocean conservation'
];

function App() {
  const [prompt, setPrompt] = useState('');
  const [temperature, setTemperature] = useState(0.7);
  const [maxLength, setMaxLength] = useState(150);
  const [generatedText, setGeneratedText] = useState('');
  const [isGenerating, setIsGenerating] = useState(false);
  const [displayedText, setDisplayedText] = useState('');
  const [showComparison, setShowComparison] = useState(false);
  const [lowTempText, setLowTempText] = useState('');
  const [highTempText, setHighTempText] = useState('');

  // Simulate text generation with typing effect
  const generateText = async () => {
    if (!prompt.trim()) return;
    
    setIsGenerating(true);
    setGeneratedText('');
    setDisplayedText('');
    setShowComparison(false);
    
    // Simulate API delay
    await new Promise(resolve => setTimeout(resolve, 1000));
    
    // Get appropriate text based on topic and temperature
    const topic = prompt.toLowerCase();
    let text = '';
    
    if (textSamples[topic]) {
      text = temperature > 0.8 ? textSamples[topic].high : textSamples[topic].low;
    } else {
      // Generic response for unknown topics
      text = temperature > 0.8 
        ? `The fascinating world of ${prompt} unfolds like an intricate tapestry, weaving together threads of possibility and wonder. Each aspect sparkles with unique characteristics that dance through the imagination, creating a symphony of ideas that resonates with both mystery and clarity.`
        : `The topic of ${prompt} encompasses various important aspects that merit detailed consideration. This subject involves multiple components that interact in complex ways, requiring careful analysis to fully understand its implications and applications in relevant contexts.`;
    }
    
    // Truncate based on maxLength
    const words = text.split(' ');
    const truncatedWords = words.slice(0, Math.floor(maxLength / 6)); // Rough word count estimation
    const finalText = truncatedWords.join(' ');
    
    setGeneratedText(finalText);
    setIsGenerating(false);
    
    // Start typing animation
    typeText(finalText);
  };

  const typeText = (text: string) => {
    let index = 0;
    const interval = setInterval(() => {
      if (index < text.length) {
        setDisplayedText(text.substring(0, index + 1));
        index++;
      } else {
        clearInterval(interval);
      }
    }, 30);
  };

  const showTemperatureComparison = async () => {
    if (!prompt.trim()) return;
    
    setShowComparison(true);
    
    const topic = prompt.toLowerCase();
    if (textSamples[topic]) {
      setLowTempText(textSamples[topic].low);
      setHighTempText(textSamples[topic].high);
    } else {
      setLowTempText(`The topic of ${prompt} encompasses various important aspects that merit detailed consideration. This subject involves multiple components that interact in complex ways, requiring careful analysis to fully understand its implications and applications.`);
      setHighTempText(`The fascinating world of ${prompt} unfolds like an intricate tapestry, weaving together threads of possibility and wonder. Each aspect sparkles with unique characteristics that dance through the imagination, creating a symphony of ideas.`);
    }
  };

  const resetGeneration = () => {
    setPrompt('');
    setGeneratedText('');
    setDisplayedText('');
    setShowComparison(false);
    setTemperature(0.7);
    setMaxLength(150);
  };

  return (
    <div className="min-h-screen bg-gradient-to-br from-slate-900 via-purple-900 to-slate-900">
      <div className="container mx-auto px-4 py-8">
        {/* Header */}
        <div className="text-center mb-12">
          <div className="flex items-center justify-center gap-3 mb-4">
            <Brain className="w-10 h-10 text-purple-400" />
            <h1 className="text-4xl font-bold text-white">Generative Text Model</h1>
          </div>
          <p className="text-gray-300 text-lg max-w-2xl mx-auto">
            Explore the fascinating world of AI text generation. Input topics and watch as our model creates coherent, engaging paragraphs tailored to your prompts.
          </p>
        </div>

        {/* Main Interface */}
        <div className="max-w-4xl mx-auto">
          <div className="bg-white/10 backdrop-blur-lg rounded-2xl p-8 shadow-2xl border border-white/20">
            {/* Input Section */}
            <div className="mb-8">
              <label className="block text-white text-lg font-semibold mb-4">
                <BookOpen className="inline w-5 h-5 mr-2" />
                Enter your topic or prompt
              </label>
              <input
                type="text"
                value={prompt}
                onChange={(e) => setPrompt(e.target.value)}
                placeholder="e.g., artificial intelligence, climate change, space exploration..."
                className="w-full px-4 py-3 rounded-xl bg-white/20 border border-white/30 text-white placeholder-gray-300 focus:outline-none focus:ring-2 focus:ring-purple-400 focus:border-transparent"
              />
              
              {/* Example Prompts */}
              <div className="mt-4">
                <p className="text-gray-300 text-sm mb-2">Try these example prompts:</p>
                <div className="flex flex-wrap gap-2">
                  {examplePrompts.map((example, index) => (
                    <button
                      key={index}
                      onClick={() => setPrompt(example)}
                      className="px-3 py-1 bg-purple-600/30 text-purple-200 rounded-full text-sm hover:bg-purple-600/50 transition-colors border border-purple-400/30"
                    >
                      {example}
                    </button>
                  ))}
                </div>
              </div>
            </div>

            {/* Parameters Section */}
            <div className="mb-8">
              <div className="flex items-center gap-2 mb-4">
                <Settings className="w-5 h-5 text-white" />
                <h3 className="text-white text-lg font-semibold">Model Parameters</h3>
              </div>
              
              <div className="grid md:grid-cols-2 gap-6">
                {/* Temperature Control */}
                <div className="space-y-3">
                  <label className="block text-gray-300 font-medium">
                    Temperature: {temperature.toFixed(1)}
                  </label>
                  <input
                    type="range"
                    min="0.1"
                    max="1.0"
                    step="0.1"
                    value={temperature}
                    onChange={(e) => setTemperature(parseFloat(e.target.value))}
                    className="w-full h-2 bg-gray-700 rounded-lg appearance-none cursor-pointer slider"
                  />
                  <p className="text-xs text-gray-400">
                    Lower = More focused, Higher = More creative
                  </p>
                </div>

                {/* Max Length Control */}
                <div className="space-y-3">
                  <label className="block text-gray-300 font-medium">
                    Max Length: {maxLength} words
                  </label>
                  <input
                    type="range"
                    min="50"
                    max="300"
                    step="25"
                    value={maxLength}
                    onChange={(e) => setMaxLength(parseInt(e.target.value))}
                    className="w-full h-2 bg-gray-700 rounded-lg appearance-none cursor-pointer slider"
                  />
                  <p className="text-xs text-gray-400">
                    Controls the length of generated text
                  </p>
                </div>
              </div>
            </div>

            {/* Action Buttons */}
            <div className="flex flex-wrap gap-4 mb-8">
              <button
                onClick={generateText}
                disabled={isGenerating || !prompt.trim()}
                className="flex items-center gap-2 px-6 py-3 bg-gradient-to-r from-purple-600 to-blue-600 text-white rounded-xl hover:from-purple-700 hover:to-blue-700 disabled:opacity-50 disabled:cursor-not-allowed transition-all duration-200 shadow-lg hover:shadow-xl"
              >
                {isGenerating ? (
                  <>
                    <Zap className="w-5 h-5 animate-spin" />
                    Generating...
                  </>
                ) : (
                  <>
                    <Play className="w-5 h-5" />
                    Generate Text
                  </>
                )}
              </button>

              <button
                onClick={showTemperatureComparison}
                disabled={!prompt.trim()}
                className="flex items-center gap-2 px-6 py-3 bg-gradient-to-r from-emerald-600 to-teal-600 text-white rounded-xl hover:from-emerald-700 hover:to-teal-700 disabled:opacity-50 disabled:cursor-not-allowed transition-all duration-200 shadow-lg hover:shadow-xl"
              >
                <Sparkles className="w-5 h-5" />
                Compare Styles
              </button>

              <button
                onClick={resetGeneration}
                className="flex items-center gap-2 px-6 py-3 bg-gray-600 text-white rounded-xl hover:bg-gray-700 transition-colors shadow-lg hover:shadow-xl"
              >
                <RotateCcw className="w-5 h-5" />
                Reset
              </button>
            </div>

            {/* Generated Text Display */}
            {(displayedText || isGenerating) && (
              <div className="mb-8">
                <h3 className="text-white text-lg font-semibold mb-4">Generated Text</h3>
                <div className="bg-gray-800/50 rounded-xl p-6 border border-gray-700">
                  {isGenerating ? (
                    <div className="flex items-center justify-center py-8">
                      <Zap className="w-8 h-8 text-purple-400 animate-spin mr-3" />
                      <span className="text-gray-300">Generating your text...</span>
                    </div>
                  ) : (
                    <p className="text-gray-100 leading-relaxed text-lg">
                      {displayedText}
                      <span className="animate-pulse">|</span>
                    </p>
                  )}
                </div>
              </div>
            )}

            {/* Temperature Comparison */}
            {showComparison && (
              <div className="mb-8">
                <h3 className="text-white text-lg font-semibold mb-4">
                  <Sparkles className="inline w-5 h-5 mr-2" />
                  Creative vs. Focused Generation
                </h3>
                <div className="grid md:grid-cols-2 gap-6">
                  <div className="bg-blue-900/30 rounded-xl p-6 border border-blue-500/30">
                    <h4 className="text-blue-300 font-semibold mb-3">Focused (Low Temperature)</h4>
                    <p className="text-gray-200 leading-relaxed">{lowTempText}</p>
                  </div>
                  <div className="bg-purple-900/30 rounded-xl p-6 border border-purple-500/30">
                    <h4 className="text-purple-300 font-semibold mb-3">Creative (High Temperature)</h4>
                    <p className="text-gray-200 leading-relaxed">{highTempText}</p>
                  </div>
                </div>
              </div>
            )}

            {/* Educational Section */}
            <div className="bg-gradient-to-r from-indigo-900/30 to-purple-900/30 rounded-xl p-6 border border-indigo-500/30">
              <h3 className="text-white text-lg font-semibold mb-4">Understanding Text Generation</h3>
              <div className="space-y-3 text-gray-300">
                <p>
                  <strong className="text-white">Temperature:</strong> Controls the randomness of predictions. Lower values make the model more conservative and focused, while higher values encourage creativity and variety.
                </p>
                <p>
                  <strong className="text-white">Max Length:</strong> Determines how much text the model generates. Longer texts allow for more detailed exploration of topics.
                </p>
                <p>
                  <strong className="text-white">Prompt Engineering:</strong> The way you phrase your input significantly affects the output. Clear, specific prompts tend to produce more relevant results.
                </p>
              </div>
            </div>
          </div>
        </div>
      </div>

      <style jsx>{`
        .slider::-webkit-slider-thumb {
          appearance: none;
          width: 20px;
          height: 20px;
          border-radius: 50%;
          background: #8b5cf6;
          cursor: pointer;
          box-shadow: 0 0 0 2px #1f2937;
        }
        
        .slider::-moz-range-thumb {
          width: 20px;
          height: 20px;
          border-radius: 50%;
          background: #8b5cf6;
          cursor: pointer;
          border: 2px solid #1f2937;
        }
      `}</style>
    </div>
  );
}

export default App;